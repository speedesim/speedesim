export const globalFlags = {
  cashbackProcessed: false,
  balanceDeductOfUser: false,
  addRewardinTable: false,
};
