
export const dataForSearchPage = [
    { value : "recommended" , label : "Recommended"},
    { value : "lowest price" , label : "Lowest price"},
    { value : "most data allowance" , label : "Most data allowance"},
    { value : "lowest price per gb" , label : "Lowest price per GB"},
    { value : "longest validity" , label : "Longest validity"}
]


export const dataForTopupPage =[
    { value : "All"  , label : "All"},
    { value : "Sparks" , label : "Sparks"},
    { value : "3" , label : "3"},
    { value : "Ubigi" , label : "Ubigi"},
    { value : "eSIMGo" , label : "eSIMGo"},
    { value : "Airalo" , label : "Airalo"}
]
